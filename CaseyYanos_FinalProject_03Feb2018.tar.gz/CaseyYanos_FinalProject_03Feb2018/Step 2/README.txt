# Step 2
# Purpose: I want to load my dataset into python and poduce histograms of my data
# Written by: Casey Yanos
# Date: February 3, 2018

The step2.py contains the python script, the PBfBProject4.txt is the text file I use
in the python script, the images 1 and 2 are what are produced by the script except 
they are produced with my full dataset where the text file here only includes data
for two sites so the plots will only have two values