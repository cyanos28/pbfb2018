# Step 2
# Purpose: I want to load my dataset into python and poduce histograms of my data
# Written by: Casey Yanos
# Date: February 3, 2018

#!/usr/bin/env python

# Set the input file name
InFileName = 'PBfBProject2.txt'
# Open the input file for reading
InFile = open(InFileName, 'r')
# Initialize the counter used to keep track of line numbers
LineNumber = 0
# Loop through each line in the file
for Line in InFile:
    if LineNumber > 0: #To skip the header line; note next few lines are now further indented
        # Remove the line ending characters
        Line = Line.strip('\n')
        # Print the line
        ElementList = Line.split('\t')
        print LineNumber,":", ElementList
    LineNumber = LineNumber + 1
# After the loop is completed, close the file
InFile.close()

### I now have my datafile in python, but I ran into a few issues that I couldn't fix
# in python, one is that I have NA's in my data, I could not ignore them when producing
# plots. The other issue is that I couldn't get the program to skip the header line
# when plotting the data, so the histogram x axis would have all of the values and
# the name of the variable. I also wasn't able to convert the string variables in the
# column to a float while the header was there. I tried to add the plot commands to
# the above script within the for loop which skips the header (line 0) but I couldn't
# get the script to run that way. I ended up editing PBfBProject2.txt by
# hand, I just removed the headers, and replaced the NAs in some columns with 0s, these
# were the columns of biomass which when they were calculated, were calculated as NA
# even though they are 0, the other columns with NA's had to stay as NAs because they 
# were entries where there actually was no data available. So I just used a few of the
# variables to plot. I also wanted to make a for loop so I could make a list of the 
# variables that I wanted to plot and then just run through each item in teh list and 
# plot each one at a time, but that also wouldn't work so i only plotted two of the
# variables since doing each one separately is not efficient, which is the point of 
# programming this way.

# First I import the modules I need to make histograms:
import matplotlib.pyplot as plt
import numpy
import csv

# I create an empty variable x
x=[]
# Then I open the text file I will work from, this is the one I edited by hand
with open('PBfBProject4.txt','r') as csvfile:
	# I specify that it is a tab delimited file
	plots=csv.reader(csvfile, delimiter="\t")
	# I make a for loop so taht each row in the plots goes through the x.append
	# function so the row that I put in the [] will be interpreted as a float
	# and put into the x variable I created above, here I am using row 6 (which 
	# is actually column 6) which is the Distance From Baseline of each bay
	for row in plots:
		x.append(float(row[6]))
# I use the plt.hist function to make a histogram of x
plt.hist(x)
# Then i give it a title
plt.title('Frequency of Distance From Baseline')
#I label teh y axis as frequency
plt.ylabel('Frequency')
# and I label the x-axis, I make a sub title by using \n in between the main 
# header text and teh subheader text
plt.xlabel('Distance From Baseline\nIn Meters')
# Then I use plt.show() like print to call up the plot I created
plt.show() 
# This is saved as Figure1

# I will make one more in the same way, this time I will use row 8 which is Pike
# cpue
x=[]
with open('PBfBProject4.txt','r') as csvfile:
	plots=csv.reader(csvfile, delimiter="\t")
	for row in plots:
		x.append(float(row[8]))
plt.hist(x)
plt.title('Frequency of Pike CPUE')
plt.ylabel('Frequency')
plt.xlabel('Pike CPUE\nNumber of Pike per Day of Rod and Reel Fishing ')
plt.show()
# This is saved as Figure2
#### For my figures I used my full dataset while teh dataset provided in this 
# folder only contains data for 2 sites