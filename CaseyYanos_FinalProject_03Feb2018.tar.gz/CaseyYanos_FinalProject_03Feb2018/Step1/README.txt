# Step 1
# Purpose: To reformat my data so I can perform analysis on it. Because I didn't realize
# my data wasn't structured how I had intended it to be, and because reformatting my
# data was not originally part of my project, I did this step in R to save time.
# Written by: Casey Yanos
# Date: February 03, 2018
### I am starting on my data management for analysis. I am first going to create a data
# set which has a single row for each bay, so 27 rows, and will just have the averages
# for values where there are multiple measurements such as fish from 5 nets, here I will
# simply have a column for average fish biomass instead of listing each net biomass because
# I first want to do analysis on the bay scale, later I will look at within bay and then
# I can look at the variation between nets in a single bay, etc
### I start by reading in the metadatafish_reformatted file which I currently have in my 
# data folder
fish<-read.table(file.choose(), header=T, sep="\t") # use metadatafish_reformatted
View(fish)
names(fish)
### I want to start by finding the average biomass per species but I have multiple rows per
# species because of the different sizes, I also have multiple rows per size because Eeke
# had made it so each fish had its own row, I will start by removing these duplicates so
# I only have a single row per species per size per net per bay, for this I will use the
# duplicated function which finds all duplicates within the fish dataframe, then I create
# a new dataframe called fish2 without the duplicates by stating !duplicated
fish2<-fish[!duplicated(fish), ]
### I still have a lot of duplicates but I need to work with them first and then I can
# remove them later. I first need to find the average biomass of each species
attach(fish2)
### Excel had saved the biomass values as factors so I have to convert them to numeric so
# I can perform mathematical operations on them:
fish2$CalcWeight_kg <- as.numeric(as.character(fish2$CalcWeight_kg))
### Then I have to find the total biomass of each species per net because they are still
# split up by mesh size, since we are not looking at effect of mesh size since the sizes
# we used were the same in each net and bay, I am combining all the data of each species
# in each net per each bay using the ddply function in the reshape2 package, this creates
# a new dataframe which I call Biomass, it only has the variables Biomass, Bay, Species,
# Net, and SpeciesBiomass:
Biomass<-ddply(fish2, c("Bay","Species", "Net"), summarise,SpeciesBiomass= sum(CalcWeight_kg))
View(Biomass)
### Now I can find the average, I am using ddply to find the average of each species per
# bay, and creating a new dataframe called BiomassWithAverage:
BiomassWithAverage<-ddply(Biomass, c("Bay","Species"), summarise,AvgBiomass=mean(SpeciesBiomass))
### Now I am casting the data so that each Bay has its own row and each Species has its
# own column and the data is the AvgBiomass calculated in the above step:
BiomassCast<-dcast(BiomassWithAverage, Bay~Species, value.var="AvgBiomass")
View(BiomassCast)
### Then I duplicate my fish2 dataframe so if I need to go back to it I can
fish3<-fish2
### Then I remove all of the columns that I don't need in this dataframe
fish3$Fiske<-NULL
fish3$Area<-NULL
fish3$MeshSize<-NULL
fish3$Species<-NULL
fish3$CalcWeight_kg<-NULL
fish3$Length_cm<-NULL
fish3$LengthGroup<-NULL
fish3$Quantity<-NULL
fish3$TotalQuantityForKind<-NULL
fish3$Lat<-NULL
fish3$Long<-NULL
fish3$TempRetrieve<-NULL
fish3$TempSet<-NULL
fish3$Net<-NULL
View(fish3)
### Then I remove all of the duplicates, creating a new dataframe in the process, now I
# only have a single row per bay:
fish4<-fish3[!duplicated(fish3), ]
View(fish4)
### Now I merge what is left from the fish4 dataframe with the biomass data, I now have
# all the net biomass data saved with the bay data
FishNet<-merge(fish4,BiomassCast,by="Bay")
View(FishNet)
### Now I will add the pike data from the rod and reel fishing, this is the pike_reformatted
# text file, this is in CPUE, not biomass, because I don't have the sizes to convert
# the data to biomass, so I will leave CPUE in the header
pike<-read.table(file.choose(), header=T, sep="\t")
View(pike)
### I can merge it to the FishNet dataframe
FishNet2<-merge(FishNet,pike,by=c("Bay","Site"))
View(FishNet2)
### Now I am going to work with the fish trap data, I will load it in from TrapFishData2017
# text file
trap<-read.table(file.choose(), header=T, sep="\t")
View(trap)
### Then I duplicate it in case I need to start over
trap2<-trap
attach(trap2)
### Then I make sure the biomass data is numeric
trap2$BIOMASS_kg <- as.numeric(as.character(trap2$BIOMASS_kg))
### Then I find the total biomass per species per trap per bay
TrapBiomass<-ddply(trap2, c("Bay_number","Species_ABR", "Trap_number"), summarise,SppBiomass= sum(BIOMASS_kg))
View(TrapBiomass)
### Then I find the average biomass per bay
TrapBiomassWithAverage<-ddply(TrapBiomass, c("Bay_number","Species_ABR"), summarise,TrapAvgBiomass=mean(SppBiomass))
### Then I cast the data so each bay has its own row
TrapBiomassCast<-dcast(TrapBiomassWithAverage, Bay_number~Species_ABR, value.var="TrapAvgBiomass")
View(TrapBiomassCast)
### For some reason the data has a row 28 which is all NAs so I will remove it
TrapBiomassCast <- TrapBiomassCast[-c(28), ]
### Then I remove a few useless columns to save space
TrapBiomassCast$`TRAP LOST`<-NULL
TrapBiomassCast$Var.2<-NULL
### Then I rename the Bay_number column to Bay to match the other dataframe
colnames(TrapBiomassCast)[1] <- "Bay"
### Then I merge it to the FishNet2 dataframe and I now have all of the fish data in
# a single dataframe
FishAll<-merge(FishNet2,TrapBiomassCast,by=c("Bay"))
View(FishAll)
### I need to add the CPUE for each species since the pike rod and reel
# fishing only has CPUE data, I will basically do the same as I did for
# the biomass data but using the TotalQuantityForKind variable which is
# the count of each species per size per net per bay
### First I duplicate the fish2 dataframe
fishCPUE<-fish2
### Then I remove columns which I do not need
fishCPUE$Fiske<-NULL
fishCPUE$Area<-NULL
fishCPUE$MeshSize<-NULL
fishCPUE$CalcWeight_kg<-NULL
# fishCPUE$Length_cm<-NULL # I keep this because I need all the sizes to add up because TotalQuantityForKind is not summed over sizes
fishCPUE$LengthGroup<-NULL
fishCPUE$Quantity<-NULL
fishCPUE$Lat<-NULL
fishCPUE$Long<-NULL
fishCPUE$TempRetrieve<-NULL
fishCPUE$TempSet<-NULL
fishCPUE$Season<-NULL
fishCPUE$Site<-NULL
fishCPUE$Protection<-NULL
fishCPUE$BayPosition1<-NULL
fishCPUE$BayPosition2<-NULL
fishCPUE$DistanceFromBaseline<-NULL
fishCPUE$Area_ha<-NULL
View(fishCPUE)
### I removed duplicates so I only have one total for each size, species, bay, net
fishCPUE<-fishCPUE[!duplicated(fishCPUE), ]
### I make TotalQuantityForKind numeric so I can perform mathematical operations
fishCPUE$TotalQuantityForKind <- as.numeric(as.character(fishCPUE$TotalQuantityForKind))
### I find the total for each species by summing across all occurences
# regardless of size for each bay and net, so I now have up to five totals
# for each species for each bay because I can have up to five nets
Counts<-ddply(fishCPUE, c("Bay","Species", "Net"), summarise,SpeciesCPUE= sum(TotalQuantityForKind))
View(Counts)
### then I find the average CPUE for each species across all nets
CountsAverage<-ddply(Counts, c("Bay","Species"), summarise,AvgCPUE=mean(SpeciesCPUE))
View(CountsAverage)
### Then I make each bay have its own row
CountsCast<-dcast(CountsAverage, Bay~Species, value.var="AvgCPUE")
View(CountsCast)
### Then I merge it to the main dataframe
FishFinal<-merge(FishAll,CountsCast,by="Bay")
View(FishFinal)
### Species.x is biomass, species.y is cpue
##
##
### Then I repeat with the trap data so I have CPUE for the traps
trap3<-trap
attach(trap3)
### Then I make sure the count data is numeric
trap3$Number_per_trap <- as.numeric(as.character(trap3$Number_per_trap))
### Then I find the total count per species per trap per bay
TrapCPUE<-ddply(trap3, c("Bay_number","Species_ABR", "Trap_number"), summarise,SppCount= sum(Number_per_trap))
View(TrapCPUE)
### Then I find the average count per bay
TrapCPUEWithAverage<-ddply(TrapCPUE, c("Bay_number","Species_ABR"), summarise,TrapAvgCPUE=mean(SppCount))
View(TrapCPUEWithAverage)
### Then I cast the data so each bay has its own row
TrapCPUECast<-dcast(TrapCPUEWithAverage, Bay_number~Species_ABR, value.var="TrapAvgCPUE")
View(TrapCPUECast)
### For some reason the data has a row 28 which is all NAs so I will remove it
TrapCPUECast <- TrapCPUECast[-c(28), ]
### Then I remove a few useless columns to save space
TrapCPUECast$`TRAP LOST`<-NULL
TrapCPUECast$Var.2<-NULL
### Then I rename the Bay_number column to Bay to match the other dataframe
colnames(TrapCPUECast)[1] <- "Bay"
### THen I merge everything
FishFinal2<-merge(FishFinal,TrapCPUECast,by="Bay")
View(FishFinal2)
### Species.x is biomass, species.y is cpue
##
##
### Now I will add the vegetation % cover data from the nets
NetVeg<-read.table(file.choose(), header=T, sep="\t") # using NetVegData2017_reformatted
View(NetVeg)
NetVeg2<-NetVeg
### There are two values of percent cover for each net so I first find
# the average by using rowMeans and specifying the columns which the data
# for the means is in
NetVeg2$VegAvg<-rowMeans(NetVeg2[c(15,71)],na.rm=T)
View(NetVeg2)
### Then I make sure the average is numeric
NetVeg2$VegAvg <- as.numeric(as.character(NetVeg2$VegAvg))
### Then I find the average per bay
NetVegAverage<-ddply(NetVeg2, ("Bay"), summarise,NetVegAvg=mean(VegAvg))
View(NetVegAverage)
### Then I merge it with the fish data
FishFinal3<-merge(FishFinal2,NetVegAverage,by="Bay")
View(FishFinal3)
##
##
### Now I will add the vegetation cover % data from the traps
TrapVeg<-read.table(file.choose(), header=T, sep="\t") # Using the TrapVegData2017 text file
View(TrapVeg)
TrapVeg2<-TrapVeg
### Make the veg data a numeric
TrapVeg2$TotalVegetation_percent <- as.numeric(as.character(TrapVeg2$TotalVegetation_percent))
### Find the average per bay
TrapVegAverage<-ddply(TrapVeg2, ("Bay_number"), summarise,TrapVegAvg=mean(TotalVegetation_percent,na.rm=T)) # I add na.rm=T because one of the values for % cover is an NA and I don't want the calculation to be forced to result in NA
View(TrapVegAverage)
### Remove row 28 which is blank
TrapVegAverage <- TrapVegAverage[-c(28), ]
### Rename Bay_number to Bay
colnames(TrapVegAverage)[1] <- "Bay"
### Merge with the fish and netveg data
FishFinal4<-merge(FishFinal3,TrapVegAverage,by="Bay")
View(FishFinal4)
###
##
##
### Now I will add spring and summer temp and salinity as well as summer 
# % veg cover from around the settling tiles, all of this is in the 
# ASUandTileData2017 text file
Env<-read.table(file.choose(), header=T, sep="\t")
View(Env)
Env2<-Env
View(Env2)
Env2$TotalVegetation_percent <- as.numeric(as.character(Env2$TotalVegetation_percent))
EnvVegAverage<-ddply(Env2, ("Bay_number"), summarise,SummerAvgVeg=mean(TotalVegetation_percent))
View(EnvVegAverage)
### Remove row 28 which is blank
EnvVegAverage <- EnvVegAverage[-c(28), ]
### Rename Bay_number to Bay
colnames(EnvVegAverage)[1] <- "Bay"
### Merge with the fish and netveg data
FishFinal5<-merge(FishFinal4,EnvVegAverage,by="Bay")
View(FishFinal5)
### Spring Temp
SpTemp<-Env
SpTemp$Temp_set <- as.numeric(as.character(SpTemp$Temp_set))
SpTempAverage<-ddply(SpTemp, ("Bay_number"), summarise,SpringTemp=mean(Temp_set))
View(SpTempAverage)
### Remove row 28 which is blank
SpTempAverage <- SpTempAverage[-c(28), ]
### Rename Bay_number to Bay
colnames(SpTempAverage)[1] <- "Bay"
### Merge with the fish and netveg data
FishFinal6<-merge(FishFinal5,SpTempAverage,by="Bay")
View(FishFinal6)
### SummerTemp
SuTemp<-Env
SuTemp$Temp_lift <- as.numeric(as.character(SuTemp$Temp_lift))
SuTempAverage<-ddply(SuTemp, ("Bay_number"), summarise,SummerTemp=mean(Temp_lift))
View(SuTempAverage)
### Remove row 28 which is blank
SuTempAverage <- SuTempAverage[-c(28), ]
### Rename Bay_number to Bay
colnames(SuTempAverage)[1] <- "Bay"
### Merge with the fish and netveg data
FishFinal7<-merge(FishFinal6,SuTempAverage,by="Bay")
View(FishFinal7)
### Spring Salinity
SpSal<-Env
SpSal$Sal_set <- as.numeric(as.character(SpSal$Sal_set))
SpSalAverage<-ddply(SpSal, ("Bay_number"), summarise,SpringSalinity=mean(Sal_set))
View(SpSalAverage)
### Remove row 28 which is blank
SpSalAverage <- SpSalAverage[-c(28), ]
### Rename Bay_number to Bay
colnames(SpSalAverage)[1] <- "Bay"
### Merge with the fish and netveg data
FishFinal8<-merge(FishFinal7,SpSalAverage,by="Bay")
View(FishFinal8)
### Summer Salinity
SuSal<-Env
SuSal$Sal_lift <- as.numeric(as.character(SuSal$Sal_lift))
SuSalAverage<-ddply(SuSal, ("Bay_number"), summarise,SummerSalinity=mean(Sal_lift))
View(SuSalAverage)
### Remove row 28 which is blank
SuSalAverage <- SuSalAverage[-c(28), ]
### Rename Bay_number to Bay
colnames(SuSalAverage)[1] <- "Bay"
### Merge with the fish and netveg data
FishFinal9<-merge(FishFinal8,SuSalAverage,by="Bay")
View(FishFinal9)
write.csv(FishFinal9, file="C:/Users/user/Desktop/FishFinal.csv")
