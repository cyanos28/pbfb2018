# Step 4
# Purpose: Create maps of the data
# Written by: Casey Yanos
# Date: February 03, 2018

I tried to create maps in python but I was having trouble loading the modules
that I needed so I did it in R instead, I would like to make a for loop so
I can use one chunk of code and loop it through all of my sampling sites but
I couldnt' get it to work so I made a single plot in r to show what I would
like to produce in python, the R script is saved in CoordinatesScript.txt, 
the datafile is Coordinates.txt, and teh map is saved as Figure1
