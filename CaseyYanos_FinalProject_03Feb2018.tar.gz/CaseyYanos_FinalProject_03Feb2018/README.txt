# Project: Final Project for Practical Bioinformatics for Biologists
# Written by: Casey Yanos
# Date: February 03, 2018

For this project I was trying to do some exploratory data analysis however I 
ended up doing mostly data management, which I performed mostly in R because
I wanted to do it quickly so I could get to some analysis in python. I am much
less familiar with python so a lot of things that I can do quickly in R took
me a lot of time to figure out in python so I ended up doing less things than
I had originally intended. My first step was to restructure my data which I did
in R to save time. My second step was to work with my data in python to create
histograms of my variables to see their distribution. My third step was to 
create scatterplots to look at relationships between variables. My fourth step
was to create maps of my sampling sites, I did this in R because I was unable
to load some of the necessary modules in python. For steps 1, 2, and 3 I used 
my full dataset but only provide data from two of my sites here, so the images
produced will look slightly different than the ones I provide here.