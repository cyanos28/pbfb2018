# Step 3
# Purpose: Create scatterplots of two variables in my dataset to see any
# possible relationships in the data
# Written by: Casey Yanos
# Date: February 03, 2018

#!/usr/bin/env python
# First I import the modules I need
import matplotlib.pyplot as plt
import numpy
import csv

# I create empty variables for x and y
x=[]
y=[]
# I open my datafile, use r for read, and as csvfile so it knows that it is a
# file to open
with open('PBfBProject4.txt','r') as csvfile:
	# I use plots=csv.reader so it knows that when I call up plots it is supposed
	# to use the csv.reader function to read csvfile which is tab delimited
	plots=csv.reader(csvfile, delimiter="\t")
	# I create a for loop so each row in plots when called up will append one of
	# the variables, here row 9 will be put into the x variable and 10 into the y
	# I also use the float function to make the string variables in my file floats
	# Here I am plotting perch (row 9) vs stickleback (row 10)
	for row in plots:
		x.append(float(row[9]))
		y.append(float(row[10]))
# then i use the plt.scatter function to plot x vs y
plt.scatter(x,y)
# I add a title
plt.title('Perch vs Stickleback CPUE')
# I add a y label, using \n to separate the main and sub titles
plt.ylabel('Stickleback CPUE\nNumber of Stickleback per Day of Net Fishing')
# and do the same for teh y label
plt.xlabel('Perch CPUE\nNumber of Perch per Day of Net Fishing')
# then I call up the plot I created
plt.show()
# this is saves as Figure1 in the folder

# I repeat this one more time so I can try out a few functions
x=[]
y=[]
with open('PBfBProject4.txt','r') as csvfile:
	plots=csv.reader(csvfile, delimiter="\t")
	for row in plots:
		x.append(float(row[10]))
		y.append(float(row[12]))
# up to here the script is the same, except i am using different variables, but
# in the next line I use marker="*" to make the marker shape a star instead of 
# a circle, which is uneccesary here but can be useful when I am plotting more 
# than one variable on teh same plot, and I use s=500 to increase the size of the
# markers, again it is pointless now but could be useful later
plt.scatter(x,y,marker="*",s=500)
plt.title('Stickleback CPUE vs Vegetation')
plt.ylabel('Percent Cover of Vegetation')
plt.xlabel('Stickleback CPUE\nNumber of Stickleback per Day of Net Fishing')
plt.show()
# I save this as Figure2