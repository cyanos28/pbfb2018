# Step 3
# Purpose: Create scatterplots of two variables in my dataset to see any
# possible relationships in the data
# Written by: Casey Yanos
# Date: February 03, 2018

The python script for this step is saved as step3.py, the images produced by 
the script are saves as Figure1 and Figure2, the text file of data is 
PBfBProject4.txt, it only contains data for two of my sites while the images I
produced used my full data set so the images will look different